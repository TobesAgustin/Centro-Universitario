namespace CentroEventos.Aplicacion.Exceptions
{
    public class EntidadNotFoundException(string mensaje) : Exception(mensaje)
    {
    }
}