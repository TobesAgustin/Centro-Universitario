namespace CentroEventos.Aplicacion.Exceptions
{
    public class DuplicadoException(string mensaje) : Exception(mensaje)
    {
    }
}