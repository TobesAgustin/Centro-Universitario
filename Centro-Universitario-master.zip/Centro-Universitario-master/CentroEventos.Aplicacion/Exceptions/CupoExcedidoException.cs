namespace CentroEventos.Aplicacion.Exceptions
{
    public class CupoExcedidoException(string mensaje) : Exception(mensaje)
    {
    }
}