namespace CentroEventos.Aplicacion.Exceptions;

public class ValidacionExcepcion(string mensaje) : Exception(mensaje)
{
}