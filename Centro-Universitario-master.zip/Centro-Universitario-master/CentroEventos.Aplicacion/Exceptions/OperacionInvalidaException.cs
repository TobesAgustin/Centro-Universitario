namespace CentroEventos.Aplicacion.Exceptions
{
    public class OperacionInvalidaException(string mensaje) : Exception(mensaje)
    {
    }
}