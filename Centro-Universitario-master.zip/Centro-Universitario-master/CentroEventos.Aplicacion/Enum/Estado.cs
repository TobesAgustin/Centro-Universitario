namespace CentroEventos.Aplicacion.Enum;

public enum Estado
{
    Pendiente = 1,
    Presente = 2,
    Ausente = 3
}